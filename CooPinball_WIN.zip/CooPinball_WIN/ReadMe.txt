Co-oPinball

Have 2 players controller a side of flippers in pinball to reach the highest score you can.

S + Down Arrow - Start Game
Z - Left Flipper
7 - Right Flipper
A + Left Arrow - Tilt Left
D + Right Arrow - Right Tilt

A tilting mechanic was implemented by having the ball slightly propelled when both players press right or left buttons
